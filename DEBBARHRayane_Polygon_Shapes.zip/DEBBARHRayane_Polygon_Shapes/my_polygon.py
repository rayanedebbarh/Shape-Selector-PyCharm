"""
Rayane Debbarh
02/11/2024
Lab 05
"""


from abc import ABC, abstractmethod


class Polygon(ABC):
    @abstractmethod

    def area(self):
        pass

    @abstractmethod

    def perimeter(self):
        pass

    @abstractmethod

    def draw(self, width, height):
        pass