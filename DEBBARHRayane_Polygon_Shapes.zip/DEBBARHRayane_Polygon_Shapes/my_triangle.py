"""
Rayane Debbarh
02/11/2024
Lab 05
"""


from my_polygon import Polygon
import graphics as gr
from PolygonTestDisplay import randtheta, sind, cosd
from random import randint
from math import *

def make_point(a,b, equi=False):
    centerx = 150
    centery = 150
    if equi:
        return gr.Point(50 * cosd(a) + centerx, 50 * sind(a) + centery)
    theta = randtheta(a, b)
    return gr.Point(50 * cosd(theta) + centerx, 50 * sind(theta) + centery)

class Triangle(Polygon):
    def __init__(self):
        self.point1 = make_point(0,120)
        self.point2 = make_point(120, 240)
        self.point3 = make_point(240, 360)

        self.side1 = sqrt(
            (self.point2.getX() - self.point1.getX()) ** 2 + (self.point2.getY() - self.point1.getY()) ** 2)
        self.side2 = sqrt(
            (self.point3.getX() - self.point2.getX()) ** 2 + (self.point3.getY() - self.point2.getY()) ** 2)
        self.side3 = sqrt(
            (self.point1.getX() - self.point3.getX()) ** 2 + (self.point1.getY() - self.point3.getY()) ** 2)

    def area(self):
        return f"The area of this triangle is {(self.side1 * self.side2)/2} mm²"

    def perimeter(self):
        return f"The perimeter of this triangle is {self.side1 + self.side2 + self.side3} mm"


    def draw(self, width, height):
        win = gr.GraphWin("Fun Shapes!", width, height)
        drawing = gr.Polygon(self.point1, self.point2, self.point3)
        drawing.draw(win)
        win.getMouse()
        drawing.undraw()
        win.close()



class Isocele_Triangle(Polygon):
    def __init__(self):
        self.point1 = gr.Point(50,50)
        self.point2 = gr.Point(150,50)
        self.point3 = gr.Point(100, randint(70,300))

        self.side1 = sqrt(
            (self.point2.getX() - self.point1.getX()) ** 2 + (self.point2.getY() - self.point1.getY()) ** 2)
        self.side2 = self.side3 = sqrt(
            (self.point3.getX() - self.point2.getX()) ** 2 + (self.point3.getY() - self.point2.getY()) ** 2)



    def area(self):
        return f"The area of this triangle is {(self.side1 * self.side2)/2} mm²"

    def perimeter(self):
        return f"The perimeter of this triangle is {self.side1 + self.side2 * 2} mm"


    def draw(self, width, height):
        win = gr.GraphWin("Fun Shapes!", width, height)
        drawing = gr.Polygon(self.point1, self.point2, self.point3)
        drawing.draw(win)
        win.getMouse()
        drawing.undraw()
        win.close()



class Equilateral_Triangle(Polygon):
    def __init__(self):
        self.point1 = make_point(0,120, equi=True)
        self.point2 = make_point(120,240, equi=True)
        self.point3 = make_point(240, 360, equi=True)

        self.side1 = self.side2 = self.side3 = sqrt(
            (self.point2.getX() - self.point1.getX()) ** 2 + (self.point2.getY() - self.point1.getY()) ** 2)


    def area(self):
        return f"The area of this triangle is {(self.side1 * self.side2)/2} mm²"

    def perimeter(self):
        return f"The perimeter of this triangle is {self.side1 * 3} mm"


    def draw(self, width, height):
        win = gr.GraphWin("Fun Shapes!", width, height)
        drawing = gr.Polygon(self.point1, self.point2, self.point3)
        drawing.draw(win)
        win.getMouse()
        drawing.undraw()
        win.close()


