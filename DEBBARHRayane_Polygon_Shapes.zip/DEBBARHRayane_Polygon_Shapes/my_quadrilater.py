"""
Rayane Debbarh
02/11/2024
Lab 05
"""


from my_polygon import Polygon
import graphics as gr
from PolygonTestDisplay import randtheta, sind, cosd
from math import *


def make_point(a, b, equi=False):
    centerx = 150
    centery = 150
    if equi:
        return gr.Point(50 * cosd(a) + centerx, 50 * sind(a) + centery)
    theta = randtheta(a, b)
    return gr.Point(50 * cosd(theta) + centerx, 50 * sind(theta) + centery)


class Quadrilatere(Polygon):
    def __init__(self):
        self.point1 = make_point(0, 90)
        self.point2 = make_point(90, 180)
        self.point3 = make_point(180, 270)
        self.point4 = make_point(270, 360)

        self.side1 = self.side3 = sqrt(
            (self.point2.getX() - self.point1.getX()) ** 2 + (self.point2.getY() - self.point1.getY()) ** 2)
        self.side2 = self.side4 = sqrt(
            (self.point3.getX() - self.point2.getX()) ** 2 + (self.point3.getY() - self.point2.getY()) ** 2)

    def area(self):
        area_triangle1 = 0.5 * abs(
            self.point1.getX() * (self.point2.getY() - self.point3.getY()) +
            self.point2.getX() * (self.point3.getY() - self.point1.getY()) +
            self.point3.getX() * (self.point1.getY() - self.point2.getY())
        )

        area_triangle2 = 0.5 * abs(
            self.point1.getX() * (self.point3.getY() - self.point4.getY()) +
            self.point3.getX() * (self.point4.getY() - self.point1.getY()) +
            self.point4.getX() * (self.point1.getY() - self.point3.getY())
        )
        return f"The area of this quadrilateral is {(area_triangle1 + area_triangle2)} mm²"

    def perimeter(self):
        return f"The perimeter of this quadrilateral is {self.side1 + self.side2 + self.side3 + self.side3} mm"

    def draw(self, width, height):
        win = gr.GraphWin("Fun Shapes!", width, height)
        drawing = gr.Polygon(self.point1, self.point2, self.point3, self.point4)
        drawing.draw(win)
        win.getMouse()
        drawing.undraw()
        win.close()


class Square(Polygon):
    def __init__(self):
        self.point1 = gr.Point(100, 100)
        self.point2 = gr.Point(150, 100)
        self.point3 = gr.Point(150, 50)
        self.point4 = gr.Point(100, 50)

        self.side2 = self.side3 = self.side4 = self.side1 = sqrt(
            (self.point2.getX() - self.point1.getX()) ** 2 + (self.point2.getY() - self.point1.getY()) ** 2)

    def area(self):
        return f"The area of this square is {self.side1 * self.side2} mm²"

    def perimeter(self):
        return f"The perimeter of this square is {self.side1 * 4} mm"

    def draw(self, width, height):
        win = gr.GraphWin("Fun Shapes!", width, height)
        drawing = gr.Polygon(self.point1, self.point2, self.point3, self.point4)
        drawing.draw(win)
        win.getMouse()
        drawing.undraw()
        win.close()


class Rectangle(Polygon):
    def __init__(self):
        self.point1 = gr.Point(100, 100)
        self.point2 = gr.Point(200, 100)
        self.point3 = gr.Point(200, 50)
        self.point4 = gr.Point(100, 50)

        self.side1 = self.side3 = sqrt(
            (self.point2.getX() - self.point1.getX()) ** 2 + (self.point2.getY() - self.point1.getY()) ** 2)
        self.side2 = self.side4 = sqrt(
            (self.point3.getX() - self.point2.getX()) ** 2 + (self.point3.getY() - self.point2.getY()) ** 2)

    def area(self):
        return f"The area of this rectangle is {self.side1 * self.side2} mm²"

    def perimeter(self):
        return f"The perimeter of this rectangle is {self.side1 * 2 + self.side2 * 2} mm"

    def draw(self, width, height):
        win = gr.GraphWin("Fun Shapes!", width, height)
        drawing = gr.Rectangle(self.point1, self.point3)
        drawing.draw(win)
        win.getMouse()
        drawing.undraw()
        win.close()
