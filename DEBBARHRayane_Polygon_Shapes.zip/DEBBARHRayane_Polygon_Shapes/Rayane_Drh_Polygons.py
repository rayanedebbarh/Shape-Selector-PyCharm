"""
Rayane Debbarh
02/11/2024
Lab 05
"""


import my_quadrilater
import my_triangle


def application():
    choice1 = 1
    print(f"\nHello, This is our new Beta Polygon Presentation !")
    while choice1 is not None:
        print(
            f"\n---Please chose one number of the one just bellow :"
            f"\n1 / Triangle."
            f"\n2 / Quadrilaterals."
            f"\n3 / Exit.")
        choice1 = input("Please enter you choice => ")

        if not choice1 in "123":
            print("\n!!! Your choice should be one the options given !!!\n")

        while choice1 == "1":
            print("\n\nWelcome to the Triangles section ^^."
                  "\n---Again, please chose one number of the one just bellow :"
                  "\n1 / Random Triangle"
                  "\n2 / Isosceles Triangle"
                  "\n3 / Equilateral triangle"
                  "\n4 / Go back")
            choice2 = input("Please enter you choice => ")

            if not choice2 in "1234":
                print("\n!!! Your choice should be one the options given !!!\n")

            elif choice2 == "1":
                triangle = my_triangle.Triangle()
                print(triangle.perimeter())
                print(triangle.area())
                triangle.draw(500, 400)

            elif choice2 == "2":
                triangle = my_triangle.Isocele_Triangle()
                print(triangle.perimeter())
                print(triangle.area())
                triangle.draw(500, 400)

            elif choice2 == "3":
                triangle = my_triangle.Equilateral_Triangle()
                print(triangle.perimeter())
                print(triangle.area())
                triangle.draw(500, 400)

            elif choice2 == "4":
                break

        while choice1 == "2":
            print("\n\nWelcome to the Quadrilateral section ^^."
                  "\n---Again, please chose one number of the one just bellow :"
                  "\n1 / Random Quadrilateral"
                  "\n2 / Square"
                  "\n3 / Rectangle"
                  "\n4 / Go back")
            choice3 = input("Please enter you choice => ")

            if not choice3 in "1234":
                print("\n!!! Your choice should be one the options given !!!\n")

            if choice3 == "1":
                quadri = my_quadrilater.Quadrilatere()
                print(quadri.perimeter())
                print(quadri.area())
                quadri.draw(500, 400)

            elif choice3 == "2":
                quadri = my_quadrilater.Square()
                print(quadri.perimeter())
                print(quadri.area())
                quadri.draw(500, 400)

            elif choice3 == "3":
                quadri = my_quadrilater.Rectangle()
                print(quadri.perimeter())
                print(quadri.area())
                quadri.draw(500, 400)

            elif choice3 == "4":
                break

        if choice1 == "3":
            print("\n\nYou chose to exit !!!"
                  "\n       ~~~~ Good night ~~~~")
            break


application()
